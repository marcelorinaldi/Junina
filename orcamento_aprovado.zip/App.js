import React from 'react';
import Navigation from './Navigation';
//import 'react-native-gesture-handler';

function App() {
  return (
    <Navigation />
  );
}

export default App;
